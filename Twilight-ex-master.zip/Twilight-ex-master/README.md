# Twilight-ex Music App
The Twilight-ex Music App (the name is still being debated), is an online music streaming platform that provides users access to a vast library of music that they can choose depending on what their genre preferences are.

## External Requirements
In order to build this project you first will have to install:

Android Studio: https://developer.android.com/studio
Gradle: https://gradle.org/ 
*Note: Gradle should come pre-installed with the download of android studio*

## Setup

## Running

## Deployment

## Testing

# Authors
Kendhall G. Lebron Ruiz: kendhall@email.sc.edu
Samuel Lassiter: lassites@email.sc.edu
Nicholas Mims: nmims@email.sc.edu
Adam Pallante: pallante@email.sc.edu
Jazzmin Graham: jagraham@email.sc.edu

