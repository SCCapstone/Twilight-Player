package com.example.music;

import static org.junit.jupiter.api.Assertions.*;

class SongTest {
    //TODO Unit tests for song methods
}