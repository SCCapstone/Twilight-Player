package com.example.music;

import static org.junit.jupiter.api.Assertions.*;

class PlaylistTest {
    //TODO Unit Testing for playlist methods
}