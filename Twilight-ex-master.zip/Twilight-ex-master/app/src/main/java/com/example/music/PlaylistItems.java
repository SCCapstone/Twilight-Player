package com.example.music;

import android.view.View;
import android.widget.Button;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

public class PlaylistItems extends RecyclerView.ViewHolder implements View.OnClickListener{
    public TextView songTitle;
    public Button removeSong;
    public Button goToSong;
    PlaylistRecycleView.PlaylistItemClickListener listener;

    public PlaylistItems(@NonNull View playlistItemView, PlaylistRecycleView.PlaylistItemClickListener listener) {
        super(playlistItemView);
        songTitle = playlistItemView.findViewById(R.id.titleSong);
        goToSong = playlistItemView.findViewById(R.id.goToSong);
        removeSong = playlistItemView.findViewById(R.id.removeSong);

        goToSong.setOnClickListener(this);
        removeSong.setOnClickListener(this);

        this.listener = listener;

    }

    @Override
    public void onClick(View view) {
        switch (view.getId()) {
            case R.id.goToSong:
                listener.onGoToSong(this.getLayoutPosition());

                break;
            case R.id.removeSong:
                listener.onRemoveSong(this.getLayoutPosition());
                break;

        }
    }
}
