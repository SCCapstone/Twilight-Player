package com.example.music;

import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;
import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;


import com.google.gson.Gson;

import java.util.List;


/**
 PlaylistListRecycleView handles the behavior of the RecyclerView which holds a list of PlaylistListItems
 **/
public class PlaylistListRecycleView extends RecyclerView.Adapter<PlaylistListItems> {

    List<Playlist> playlistList;
    Context context;
    public PlaylistListRecycleView(List<Playlist> playlistList) {
        this.playlistList = playlistList;

    }

    @NonNull
    @Override
    public PlaylistListItems onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        context = parent.getContext();
        LayoutInflater inflater = LayoutInflater.from(context);
        View playlistListItemView = inflater.inflate(R.layout.playlist_list_item, parent, false);
        PlaylistListItems playlistListItem = new PlaylistListItems(playlistListItemView, new PlaylistListItemClickListener(){

            @Override
            public void onRemove(int p) {
                SharedPreferences preferences = context.getSharedPreferences("playlistList", LibraryMain.MODE_PRIVATE);
                LibraryMain.currentPlaylists.remove(playlistList.get(p));
                Gson objGson = new Gson();
                String jsonString = objGson.toJson(LibraryMain.currentPlaylists);
                SharedPreferences.Editor editor = preferences.edit();
                editor.putString("listListKey", jsonString);
                editor.apply();
                notifyDataSetChanged();
            }

            /** This bad boy takes the current playlist on the recycleview and sends it to the Playlist Activity
             * as well as starts the playlist activity **/
            @Override
            public void onGoTo(int p) {
                // One method of sending playlist position to new activity.
                Intent intent = new Intent(context, PlaylistActivity.class);
                SharedPreferences positionPreferences = context.getSharedPreferences("playlistPos", PlaylistActivity.MODE_PRIVATE);
                SharedPreferences.Editor editor = positionPreferences.edit();
                editor.putInt("listPosKey", p);
                editor.apply();
                notifyDataSetChanged();
                // start new activity
                context.startActivity(intent);

                // Ok I'm not going to lie the above was SUPER stupid
                // Straight up if I ever get around to recoding this we can just make the playlists have to have unique names and use that to track the current playlist
                // It would also be safer. If somehow the wrong data gets stored in SharedPreferences, it would prevent us ending up displaying the wrong playlist when going to a playlist
                // This code is nice if we're in a situation where the playlists CAN'T have unique names, though. Still proud of it.

            }
        });

        return playlistListItem;

    }

        @Override
        public void onBindViewHolder(@NonNull PlaylistListItems holder, final int position) {
            Playlist playlist = playlistList.get(holder.getBindingAdapterPosition());
            playlist.setName(playlist.getName());
            TextView title = holder.playlistTitle;
            title.setText(playlistList.get(position).getName());

    }
        @Override
        public int getItemCount () {
            return playlistList.size();
        }

        public interface PlaylistListItemClickListener {
            void onRemove(int p);
            void onGoTo(int p);
        }
}
