package com.example.music;

import static android.app.NotificationManager.IMPORTANCE_DEFAULT;

import android.app.Notification;
import android.app.PendingIntent;
import android.app.Service;
import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.graphics.Bitmap;
import android.net.Uri;
import android.os.Binder;
import android.os.Environment;
import android.os.IBinder;

import androidx.annotation.Nullable;

import com.google.android.exoplayer2.ExoPlayer;
import com.google.android.exoplayer2.MediaItem;
import com.google.android.exoplayer2.Player;
import com.google.android.exoplayer2.TracksInfo;
import com.google.android.exoplayer2.ui.PlayerNotificationManager;
import com.google.gson.Gson;
import com.google.gson.reflect.TypeToken;

import java.io.File;
import java.util.ArrayList;
import java.util.List;

public class MusicService extends Service {

    public static final int PLAYBACK_NOTIFICATION_ID = 1;

    private PlayerNotificationManager playerNotificationManager;
    public static ExoPlayer exoPlayer;
    private final IBinder binder = new LocalBinder();
    public static boolean serviceStarted = false;
    static ArrayList<Playlist> currentPlaylists = new ArrayList<>();

    @Override
    public void onCreate(){
        super.onCreate();

    }

    public List<MediaItem> makeExoPlayerList(Playlist playlist) {
        MediaItem item;
        File path, file;
        Uri uri;
        SharedPreferences positionPreferences = getSharedPreferences("playlistPos", MODE_PRIVATE);
        int playlistPos = positionPreferences.getInt("listPosKey", 0);

        // Like this the rest of the code only knows the arraylist as List.
        List<MediaItem> mediaItems = new ArrayList<MediaItem>();
        path = Environment.getExternalStoragePublicDirectory(Environment.DIRECTORY_MUSIC);
        for(Song i : currentPlaylists.get(playlistPos).getSongs()){
//        for(Song i : LibraryMain.currentPlaylists.get(playlistPos).getSongs()){
            file = new File(path, i.getTitle() + ".mp3");
            uri = Uri.fromFile(file);
            item = MediaItem.fromUri(uri);
            mediaItems.add(item);
        }
        return mediaItems;
    }

    @Override
    public void onDestroy() {

        exoPlayer.stop();
        playerNotificationManager.setPlayer(null);
        exoPlayer.release();
        exoPlayer = null;
        stopForeground(true);
        super.onDestroy();
    }

    @Nullable
    @Override
    public IBinder onBind (Intent intent) {
        return null;
    }

    @Override
    public int onStartCommand(Intent intent, int flags, int startId) {

        serviceStarted = true;
        final Context context = this;

        SharedPreferences preferences = getSharedPreferences("playlistList", MODE_PRIVATE);
        String playlistListString = preferences.getString("listListKey", "");
        // Check if playlistList exists, if it does, retrieve string from sharedPrefs and give it the appropriate type
        if (playlistListString != "") {
            TypeToken<ArrayList<Playlist>> token = new TypeToken<ArrayList<Playlist>>(){}; // Set the type token for arraylist ( this is playlist)
            Gson aGson = new Gson();
            currentPlaylists = aGson.fromJson(playlistListString, token.getType()); // Retrieve the object we want from json using gson
        }

        if(exoPlayer == null){

            // Retrieve playlistPos from preferences
            SharedPreferences positionPreferences = getSharedPreferences("playlistPos", MODE_PRIVATE);
            int playlistPos = positionPreferences.getInt("listPosKey", 0);
            // Retrieve the selected song from preferences
            SharedPreferences currSongTitle = getSharedPreferences("currentSongName", PlaylistActivity.MODE_PRIVATE);
            String string = currSongTitle.getString("currentSong", "");

            // Playlist playlist = LibraryMain.currentPlaylists.get(playlistPos);
            Playlist playlist = currentPlaylists.get(playlistPos);
            exoPlayer = new ExoPlayer.Builder(this).build();

            // Construct the playlist for the exoplayer
            List<MediaItem> mediaItems = makeExoPlayerList(playlist);
            exoPlayer.setMediaItems(mediaItems);
            exoPlayer.prepare();

            // Makes sure the starting song is what was selected from the playlist.
            if(string != null){
                if(checkForSongIndex(string, playlist) == -1){
                    // Do nothing, -1 means the string passed wasn't a valid title for the playlist.
                } else {
                    // Jump exoplayer to the song we're looking to play first
                    exoPlayer.seekTo(checkForSongIndex(string, playlist), 0);
                }
            }

            exoPlayer.setPlayWhenReady(true);

            playerNotificationManager = new PlayerNotificationManager.Builder(context, PLAYBACK_NOTIFICATION_ID, this.getResources().getString(R.string.app_name))
                    .setChannelNameResourceId(R.string.app_name)
                    .setChannelImportance(IMPORTANCE_DEFAULT)
                    .setMediaDescriptionAdapter(new PlayerNotificationManager.MediaDescriptionAdapter() {

                        @Override
                        public String getCurrentContentTitle(Player player) {
                            // Turn character sequence from metadata title to string and return it
                            if(exoPlayer.getCurrentMediaItem().mediaMetadata.title != null){
                                final StringBuilder sb = new StringBuilder(exoPlayer.getCurrentMediaItem().mediaMetadata.title.length());
                                sb.append(exoPlayer.getCurrentMediaItem().mediaMetadata.title);
                                return sb.toString();
                            } else {
                                return "";
                            }
                        }

                        // Returns to the specified activity if the notification is clicked on
                        // Set to null if you don't want the notification to take the app to any activity when clicked on
                        @Nullable
                        @Override
                        public PendingIntent createCurrentContentIntent(Player player) {

                            Intent intent = new Intent(context, CurrentlyPlayingActivity.class);
                            return PendingIntent.getActivity(context, 0, intent, PendingIntent.FLAG_UPDATE_CURRENT);
                           // return null;
                        }

                        @Nullable
                        @Override
                        public String getCurrentContentText(Player player) {
                            return "";
                            // return null;
                        }

                        @Nullable
                        @Override
                        public Bitmap getCurrentLargeIcon(Player player, PlayerNotificationManager.BitmapCallback callback) {
                            return null;
                        }

                    }) .setNotificationListener(new PlayerNotificationManager.NotificationListener() {
                        @Override
                        public void onNotificationPosted(int notificationId, Notification notification, boolean ongoing){
                            startForeground(notificationId, notification);

                        }
                        @Override
                        public void onNotificationCancelled(int notificationId, boolean dismissedByUser) {
                            stopSelf();
                            stopForeground(true);
                        }
                    }).build();
            playerNotificationManager.setUseStopAction(false);
            try {
                playerNotificationManager.setPlayer(exoPlayer);
            } catch (Exception e){

            }
            try{
                CurrentlyPlayingActivity.styledPlayerView.setPlayer(exoPlayer);

            } catch (Exception ignore){

            }
        }

        exoPlayer.addListener(new Player.Listener(){
            @Override
            public void onTracksInfoChanged(TracksInfo tracksInfo){
                SharedPreferences positionPreferences = getSharedPreferences("playlistPos", MODE_PRIVATE);
                int playlistPos = positionPreferences.getInt("listPosKey", 0);
//                if(LibraryMain.currentPlaylists.get(playlistPos).getSongs().get(exoPlayer.getCurrentMediaItemIndex()).getTitle() != null && CurrentlyPlayingActivity.textview != null) {
//                    CurrentlyPlayingActivity.textview.setText(LibraryMain.currentPlaylists.get(playlistPos)
//                            .getSongs().get(exoPlayer.getCurrentMediaItemIndex()).getTitle());
//                }
                if(currentPlaylists.get(playlistPos).getSongs().get(exoPlayer.getCurrentMediaItemIndex()).getTitle() != null && CurrentlyPlayingActivity.textview != null) {
                    CurrentlyPlayingActivity.textview.setText(currentPlaylists.get(playlistPos)
                            .getSongs().get(exoPlayer.getCurrentMediaItemIndex()).getTitle());
                }
            }
        });

        return START_STICKY;
    }

    public class LocalBinder extends Binder {
        MusicService getService() {
            // Return this instance of LocalService so clients can call public methods
            return MusicService.this;
        }
    }

    /**
     * @param theSong - String containing the title of the song the player should start playing on creation
     * @param playlist - The playlist the song is stored in and being played from exoPlayer
     * @return Return the index of the song to be played
     */
    public int checkForSongIndex(String theSong, Playlist playlist){
        int theInt = -1;
        for(int i =0; i < playlist.getSize() ; i++){
            if(playlist.getSongAt(i).getTitle().equals(theSong)){
                theInt = i;
                return theInt;
            }
        }

        return theInt;
    }

}
