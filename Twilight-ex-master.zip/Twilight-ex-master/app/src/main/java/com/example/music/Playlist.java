package com.example.music;

import java.util.ArrayList;

public class Playlist {

    private ArrayList<Song> songs;
    private String name;

    /**
     * Constructs a playlist object with a blank list of songs
     * @param name - The name of the playlist
     */
    public Playlist(String name){
        this.name = name;
        this.songs = new ArrayList<Song>();
    }

    /**
     * Constructs a playlist object with the given name and list of songs
     * @param name - THe name of the playlist
     * @param songs - The list of the playlist songs
     */
    public Playlist(String name, ArrayList<Song> songs) {
        this.name = name;
        this.songs = songs;
    }

    /**
     * Adds a song to the end of a playlist
     * @param newSong - The new Song to be added
     */
    public void addSong(Song newSong) {
        songs.add(newSong);
    }

    /**
     * Checks whether this playlist contains a Song
     * @param song - The song to check
     * @return - Is this song already in the playlist?
     */
    public boolean containsSong(Song song) {
        return songs.contains(song);
    }

    /**
     * Adds a song at a specific index
     * @param newSong - The song to be added
     * @param location - The location for the song to be added at
     */
    public void addSongAt(Song newSong, int location) {
        songs.add(location, newSong);
    }

    /**
     * Clears the current playlist
     */
    public void clearPlaylist() {
        songs.clear();
    }

    /**
     * Removes a specific song from the playlist
     * @param song - The song to remove
     */
    public void removeSong(Song song) {
        if(containsSong(song)){
            songs.remove(song);
        }
    }

    /**
     * Returns the size of the playlist
     * @return - The playlist size
     */
    public int getSize() {
        return songs.size();
    }

    /**
     * Returns a song at a specific location
     * @param location - The location to get the song from
     * @return - The song at the location or null if that song is not in the playlist
     */
    public Song getSongAt(int location) {
        if(location >= 0 && location <= songs.size()) {
            return songs.get(location);
        }else {
            return null;
        }
    }

    /**
     * Sets the name of the playlist
     * @param name - The new playlist name
     */
    public void setName(String name) {
        this.name = name;
    }

    /**
     * Returns the name of the playlist
     * @return - The name of the playlist
     */
    public String getName() {
        return this.name;
    }

    /**
     * Sets the list of songs to a given argument
     * @param songs - The new list of songs
     */
    public void setSongs(ArrayList<Song> songs) {
        this.songs = songs;
    }

    /**
     * Returns the list of songs
     * @return - The list of songs
     */
    public ArrayList<Song> getSongs() {
        return this.songs;
    }

    /**
     * Checks if a given Playlist object is equal to this Playlist object
     * @param list - The Playlist to check
     * @return - Is the given Playlist equal to this Playlist object?
     */
    public boolean equals(Playlist list) {
        if(this.name == list.getName() && this.songs == list.getSongs()) {
            return true;
        } else {
            return false;
        }
    }
}
