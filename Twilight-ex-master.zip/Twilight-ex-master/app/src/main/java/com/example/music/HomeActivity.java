package com.example.music;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.media.MediaPlayer;
import android.os.Bundle;
import android.view.MenuItem;
import android.view.View;
import android.widget.Button;

import com.google.android.material.navigation.NavigationBarView;

public class HomeActivity extends AppCompatActivity {
    MediaPlayer player;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_home);

        /*public void play (View v){
            if (player == null) {
                player = MediaPlayer.create(this, R.raw.song);
            }
            player.start();

        }

        public void pause (View v){
            if (player != null) {
                player.pause();
            }
        }

        public void stop (View v){
            stopPlayer();
        }
        private void stopPlayer () {
            if (player != null) {
                player.release();
                player = null;
            }
        }*/
    


        // Creates bottom navigation bar and sets listener for it
        NavigationBarView bottomNav = findViewById(R.id.bottom_navigation_menu);
        bottomNav.setOnItemSelectedListener(navListener);
        bottomNav.setSelectedItemId(R.id.nav_home);

    }


    private NavigationBarView.OnItemSelectedListener navListener =
            new NavigationBarView.OnItemSelectedListener() {
                @Override
                public boolean onNavigationItemSelected(MenuItem item) {
                    switch (item.getItemId()) {
                        case R.id.nav_home:
                            // This does nothing since you are already home
                            break;
                        case R.id.nav_library:
                            Intent intent = new Intent(HomeActivity.this, LibraryMain.class);
                            startActivity(intent);
                            overridePendingTransition(0,0);
                            break;
                        case R.id.nav_current_song:
                            Intent intentTwo = new Intent(HomeActivity.this, CurrentlyPlayingActivity.class);
                            startActivity(intentTwo);
                            overridePendingTransition(0,0);
                            break;
                    }
                    return true;
                }
            };

}