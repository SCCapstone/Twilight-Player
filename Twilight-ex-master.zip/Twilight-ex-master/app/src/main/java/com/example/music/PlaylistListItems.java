package com.example.music;

import android.content.Context;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

/**
 PlaylistListItems handles the contents inside of the RecyclerView on the library page
 The RecyclerView on the library page is solely intended to be the playlist list.
 **/
public class PlaylistListItems extends RecyclerView.ViewHolder implements View.OnClickListener {

    PlaylistListRecycleView.PlaylistListItemClickListener listener;
    public TextView playlistTitle;
    public Button removeTempBtn;
    public Button goToBtn;

    public PlaylistListItems(@NonNull View playlistListItemView, PlaylistListRecycleView.PlaylistListItemClickListener listener) {
        super(playlistListItemView);
        playlistTitle = playlistListItemView.findViewById(R.id.titlePlaylist);
        removeTempBtn = playlistListItemView.findViewById(R.id.removeTempBtn);
        goToBtn = playlistListItemView.findViewById(R.id.GoToBtn);

        removeTempBtn.setOnClickListener(this);
        goToBtn.setOnClickListener(this);

        this.listener = listener;


    }

    @Override
    public void onClick(View view) {
        switch (view.getId()) {
            case R.id.GoToBtn:
                listener.onGoTo(this.getLayoutPosition());
                break;
            case R.id.removeTempBtn:
                listener.onRemove(this.getLayoutPosition());

                break;

        }
    }
}

