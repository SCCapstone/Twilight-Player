package com.example.music;

import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import com.google.gson.Gson;

import org.w3c.dom.Text;

import java.util.List;

public class PlaylistRecycleView extends RecyclerView.Adapter<PlaylistItems> {


    List<Song> playlist;
    Context context;
    public PlaylistRecycleView(List<Song> playlist) {
        this.playlist = playlist;
    }


    @NonNull
    @Override
    public PlaylistItems onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        context = parent.getContext();
        LayoutInflater inflater = LayoutInflater.from(context);
        View playlistItemView = inflater.inflate(R.layout.playlist_item, parent, false);
        PlaylistItems playlistItem = new PlaylistItems(playlistItemView, new PlaylistItemClickListener() {

            @Override
            public void onRemoveSong(int p){
                // Open the list of playlists
                // Navigate to the current playlist on the list of playlists using information from PlaylistListRecycleView
                SharedPreferences preferences = context.getSharedPreferences("playlistList", LibraryMain.MODE_PRIVATE);
                SharedPreferences positionPreferences = context.getSharedPreferences("playlistPos", PlaylistActivity.MODE_PRIVATE);
                // Navigate to the song to be removed on the current playlist, within the playListList
                int playlistPos = positionPreferences.getInt("listPosKey",  0);
                Song aSong = LibraryMain.currentPlaylists.get(playlistPos).getSongAt(p);
                // Remove the song from the list if it exists
                if(aSong != null) {
                    LibraryMain.currentPlaylists.get(playlistPos).removeSong(aSong);
                }
                // Update the current list of playlists, notify the activity that the data set it draws from has been changed
                Gson objGson = new Gson();
                String jsonString = objGson.toJson(LibraryMain.currentPlaylists);
                SharedPreferences.Editor editor = preferences.edit();
                editor.putString("listListKey", jsonString);
                editor.apply();
                notifyDataSetChanged();
                // straight up starts a new activity every time an item is removed
                // I'm sorry.
                Intent intent = new Intent(context, PlaylistActivity.class);
                context.startActivity(intent);

            }

            @Override
            public void onGoToSong(int p){
                SharedPreferences preferences = context.getSharedPreferences("currentSongName", PlaylistActivity.MODE_PRIVATE);
                SharedPreferences positionPreferences = context.getSharedPreferences("playlistPos", PlaylistActivity.MODE_PRIVATE);
                // Navigate to the song to be removed on the current playlist, within the playListList
                int playlistPos = positionPreferences.getInt("listPosKey",  0);
                Song aSong = LibraryMain.currentPlaylists.get(playlistPos).getSongAt(p);
                SharedPreferences.Editor editor = preferences.edit();
                if(aSong != null) {
                    editor.putString("currentSong", aSong.getTitle());
                    editor.apply();
                }
                CurrentlyPlayingActivity.changingSong = true;
                Intent intent = new Intent(context, CurrentlyPlayingActivity.class);
                context.startActivity(intent);


            }
        });



        return playlistItem;
    }

    @Override
    public void onBindViewHolder(@NonNull PlaylistItems holder, final int position) {
        Song song = playlist.get(holder.getBindingAdapterPosition());
        TextView title = holder.songTitle;
        title.setText(playlist.get(position).getTitle());

    }

    @Override
    public int getItemCount() {
        return playlist.size();

    }
    public interface PlaylistItemClickListener {
        void onRemoveSong(int p);
        void onGoToSong(int p);
    }
}
