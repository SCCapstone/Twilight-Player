package com.example.music;

public class Song {

    private String title, uID, DBID, URL, key, path;

    /**
     * Constructs a Song object
     * @param title - The title of the song
     * @param uID - ??? (Followed UML here)
     * @param DBID - The database ID of the song
     * @param URL - The URL of the song
     * @param path - the path of the song.
     */
    public Song(String title, String uID, String DBID, String URL, String path) {
        this.title = title;
        this.uID = uID;
        this.DBID = DBID;
        this.URL = URL;
        this.path = path;
    }

    // TEMPORARY CONSTRUCTOR FOR TESTING PURPOSES ONLY
    public Song(String title, String URL) {
        this.title = title;
        this.uID = "N/A";
        this.DBID ="N/A";
        this.URL = URL;
    }

    public Song (String title) {
        this.title = title;

    }

    public void setPath(String songPath){
        this.path = songPath;
    }

    public void setURL(String songURL){
        this.URL = songURL;
    }

    /**
     * Checks if the title contains the given argument
     * THIS IS CASE SENSITIVE
     * @param text - The text to check
     * @return - Is the argument contained within the title?
     */
    public boolean contains(String text) {
        // Should we make this case sensitive or not? Currently it is.
        return title.contains(text);
    }

    /**
     * Checks if a given Song object is equal to this Song object
     * @param song - The Song to check
     * @return - Is the given Song equal to this Song object?
     */
    public boolean equals(Song song) {
        if(this.title == song.getTitle() && this.uID == song.getUID() &&
            this.DBID == song.getDBID() && this.URL == song.getURL()) {
            return true;
        }else {
            return false;
        }
    }

    /**
     * Returns the title of the Song
     * @return - Song title
     */
    public String getTitle() {
        return this.title;
    }

    /**
     * Returns the uID of the Song
     * @return - uID of song
     */
    public String getUID() {
        return this.uID;
    }

    /**
     * Returns the Database ID of the SOng
     * @return - The DBID
     */
    public String getDBID() {
        return this.DBID;
    }

    /**
     * Returns the Song's URL
     * @return - Song URL
     */
    public String getURL() {
        return this.URL;
    }

    /**
     * Print the song object as a string
     * @return - The Song as a string
     */
    public String toString() {
        return "Title: " + this.title + "\n uID: " + this.uID + "\n DBID: " + this.DBID + "\n URL: "
                + this.URL;
    }

    // Potential database stuff, might delete later
    public String getKey() {
        return key;
    }

    public void setKey(String key) {
        this.key = key;
    }
}
