package com.example.music;

import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.view.MenuItem;

import androidx.annotation.Nullable;
import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import com.google.android.material.navigation.NavigationBarView;
import com.google.gson.Gson;
import com.google.gson.reflect.TypeToken;

import java.util.ArrayList;

public class PlaylistActivity extends AppCompatActivity {

    SharedPreferences preferences;
    SharedPreferences positionPreferences;
    RecyclerView currentSongsView;
    PlaylistRecycleView playlistRecycleView;
    static ArrayList<Playlist> currentPlaylists = new ArrayList<>();
    static ArrayList<Song> currentSongs = new ArrayList<>();
    @Override
    protected void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_playlist);


        // Start accessing position of the current playlist, stored in shared preferences
        positionPreferences = getSharedPreferences("playlistPos", MODE_PRIVATE);
        int playlistPos = positionPreferences.getInt("listPosKey", 0);

        // Start accessing sharedPreferences to get list of all playlists
        preferences = getSharedPreferences("playlistList", MODE_PRIVATE);
        String playlistListString = preferences.getString("listListKey", "");

        if (playlistListString != "") {
            TypeToken<ArrayList<Playlist>> token = new TypeToken<ArrayList<Playlist>>(){};
            Gson aGson = new Gson();
            currentPlaylists = aGson.fromJson(playlistListString, token.getType());
            currentSongs = currentPlaylists.get(playlistPos).getSongs();
        }

        // Creates views for the songs
        currentSongsView = findViewById(R.id.playlistRecycleView);
        playlistRecycleView = new PlaylistRecycleView(currentSongs);

        currentSongsView.setAdapter(playlistRecycleView);
        currentSongsView.setLayoutManager(new LinearLayoutManager(this));

        // Creates bottom navigation bar and sets listener for it
        NavigationBarView bottomNav = findViewById(R.id.bottom_navigation_menu);
        bottomNav.setOnItemSelectedListener(navListener);

    }

    private NavigationBarView.OnItemSelectedListener navListener =
            new NavigationBarView.OnItemSelectedListener() {
                @Override
                public boolean onNavigationItemSelected(MenuItem item) {
                    switch (item.getItemId()) {
                        case R.id.nav_home:
                            Intent intentThree = new Intent(PlaylistActivity.this, HomeActivity.class);
                            startActivity(intentThree);
                            overridePendingTransition(0,0);
                            break;
                        case R.id.nav_library:
                            Intent intent = new Intent(PlaylistActivity.this, LibraryMain.class);
                            startActivity(intent);
                            overridePendingTransition(0,0);
                            break;
                        case R.id.nav_current_song:
                            Intent intentTwo = new Intent(PlaylistActivity.this, CurrentlyPlayingActivity.class);
                            startActivity(intentTwo);
                            overridePendingTransition(0,0);
                            break;
                    }
                    return true;
                }
            };

}
