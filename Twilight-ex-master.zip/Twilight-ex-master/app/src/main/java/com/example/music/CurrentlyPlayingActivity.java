package com.example.music;

import android.app.Activity;
import android.content.ComponentName;
import android.content.Context;
import android.content.Intent;
import android.content.ServiceConnection;
import android.os.Build;
import android.os.Bundle;
import android.os.IBinder;
import android.view.MenuItem;
import android.widget.TextView;

import com.google.android.exoplayer2.ExoPlayer;
import com.google.android.exoplayer2.ui.StyledPlayerView;
import com.google.android.exoplayer2.util.Util;
import com.google.android.material.navigation.NavigationBarView;

public class CurrentlyPlayingActivity extends Activity {

    MusicService aService;
    boolean mBound = false;
    public static boolean changingSong = false;
    public static StyledPlayerView styledPlayerView;
    // ExoPlayer exoPlayer;
    public static TextView textview;

    @Override
    public void onCreate (Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_currently_playing);
        styledPlayerView = findViewById(R.id.styledPlayer);
        textview = findViewById(R.id.songName);

        // Bottom nav bar stuff
        NavigationBarView bottomNav = findViewById(R.id.bottom_navigation_menu);
        bottomNav.setOnItemSelectedListener(navListener);
        bottomNav.setSelectedItemId(R.id.nav_current_song);

    }

    protected void onStart(){
        super.onStart();
        if(MusicService.serviceStarted) {
            if(connection == null) {
                Intent intent1 = new Intent(this, MusicService.class);
                bindService(intent1, connection, Context.BIND_AUTO_CREATE);
            }
        }
        styledPlayerView = findViewById(R.id.styledPlayer);

        if(LibraryMain.libraryOpen) {
            broImDone();
        }
    }

    protected void onDestroy(){
        super.onDestroy();
        if(connection != null){
            unbindService(connection);
        }
    }

    // Handles minimizing the app and returning to it. Initial tests seem mostly fine
    public void onResume(){
        super.onResume();
        if(connection == null) {
            Intent intent1 = new Intent(this, MusicService.class);
            bindService(intent1, connection, Context.BIND_AUTO_CREATE);
        }
        styledPlayerView = findViewById(R.id.styledPlayer);
        // ExoPlayer exoPlayer = MusicService.exoPlayer;
        styledPlayerView.setPlayer(MusicService.exoPlayer);
    }

    // Binds
    private ServiceConnection connection = new ServiceConnection() {
        @Override
        public void onServiceConnected(ComponentName className,
                                       IBinder service) {
            MusicService.LocalBinder binder = (MusicService.LocalBinder) service;
            aService = binder.getService();
            mBound = true;
        }

        @Override
        public void onServiceDisconnected(ComponentName arg0) {
            mBound = false;
        }
    };


    private NavigationBarView.OnItemSelectedListener navListener =
            new NavigationBarView.OnItemSelectedListener() {
                @Override
                public boolean onNavigationItemSelected(MenuItem item) {
                    switch (item.getItemId()) {
                        case R.id.nav_home:
                            Intent intent2 = new Intent(CurrentlyPlayingActivity.this, HomeActivity.class);
                            startActivity(intent2);
                            overridePendingTransition(0,0);
                            break;
                        case R.id.nav_library:
                            Intent intent = new Intent(CurrentlyPlayingActivity.this, LibraryMain.class);
                            startActivity(intent);
                            overridePendingTransition(0,0);
                            break;
                        case R.id.nav_current_song:
                            // Do nothing, you're already here
                            break;
                    }
                    return true;
                }
            };

    // Checks to see if musicService is running. If the service is running, check if the song is changing. If the song is changing,
    // run broImDoneWithin

    public void broImDone() {

        if(MusicService.serviceStarted) {
            if(!changingSong) {
                if (connection == null) {
                    Intent intent1 = new Intent(this, MusicService.class);
                    bindService(intent1, connection, Context.BIND_AUTO_CREATE);
                }
                styledPlayerView = findViewById(R.id.styledPlayer);
                // ExoPlayer exoPlayer = MusicService.exoPlayer;
                styledPlayerView.setPlayer(MusicService.exoPlayer);
            } else {
                broImDoneWithin();
            }

        } else {
            broImDoneWithin();
        }
    }

    // if the service isn't running that means it needs to stop AND that the song isn't changing
    // restarts the service or starts it if it hasn't been already.
    // resets changingSong flag to false
    public void broImDoneWithin(){
        changingSong = false;
        // TEST CODE
        Intent intent = new Intent(CurrentlyPlayingActivity.this, MusicService.class);
        try {
            stopService(intent);

        } catch (Exception e) {

        }
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            Util.startForegroundService(this, intent);
        } else {
            startService(intent);
        }
    }
}
