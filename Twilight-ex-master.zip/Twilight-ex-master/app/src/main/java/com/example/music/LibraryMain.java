package com.example.music;

import static android.os.Environment.DIRECTORY_MUSIC;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import android.app.DownloadManager;
import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.net.Uri;
import android.os.Bundle;
import android.os.Environment;
import android.view.Gravity;
import android.view.MenuItem;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.EditText;
import android.widget.PopupWindow;
import android.widget.Toast;

import com.google.android.gms.tasks.OnFailureListener;
import com.google.android.gms.tasks.OnSuccessListener;
import com.google.android.material.navigation.NavigationBarView;
import com.google.firebase.storage.FirebaseStorage;
import com.google.firebase.storage.StorageReference;
import com.google.gson.Gson;
import com.google.gson.reflect.TypeToken;

import java.io.File;
import java.util.ArrayList;

public class LibraryMain extends AppCompatActivity {

    // List of all playlists for the user.
    // static ArrayList<Playlist> currentPlaylists = new ArrayList<>();
    static ArrayList<Playlist> currentPlaylists = new ArrayList<>();
    // Preferences for the user.
    SharedPreferences preferences;
    // Stuff specifically for creating the view and controlling activity of the playlists for the user
    RecyclerView currentPlaylistsView;
    PlaylistListRecycleView playlistListRecycleView;

    // Firebase Storage Stuff
    FirebaseStorage firebaseStorage;
    StorageReference storageReference;
    StorageReference ref;
    public static boolean libraryOpen = false;

    @Override
    protected void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_library_main);

            // Start accessing shared preferences
            preferences = getSharedPreferences("playlistList", MODE_PRIVATE);
            String playlistListString = preferences.getString("listListKey", "");
            // Check if playlistList exists, if it does, retrieve string from sharedPrefs and give it the appropriate type
            if (playlistListString != "") {
                TypeToken<ArrayList<Playlist>> token = new TypeToken<ArrayList<Playlist>>(){}; // Set the type token for arraylist ( this is playlist)
                Gson aGson = new Gson();
                currentPlaylists = aGson.fromJson(playlistListString, token.getType()); // Retrieve the object we want from json using gson
            }

            if(!currentPlaylists.isEmpty()){
                libraryOpen = true;
            }

        // Creates list of playlists
        currentPlaylistsView = findViewById(R.id.playlistListRecycleView);
        playlistListRecycleView = new PlaylistListRecycleView(currentPlaylists);

        currentPlaylistsView.setAdapter(playlistListRecycleView);
        currentPlaylistsView.setLayoutManager(new LinearLayoutManager(this));

        // Creates bottom navigation bar and sets listener for it
        NavigationBarView bottomNav = findViewById(R.id.bottom_navigation_menu);
        bottomNav.setOnItemSelectedListener(navListener);
        bottomNav.setSelectedItemId(R.id.nav_library);

        // Creates top
        NavigationBarView topNav = findViewById(R.id.library_add_remove_playlist_bar);
        topNav.setOnItemSelectedListener(topNavListener);

    }

    // Bottom Navigation bar listener
    private NavigationBarView.OnItemSelectedListener navListener =
            new NavigationBarView.OnItemSelectedListener() {
                @Override
                public boolean onNavigationItemSelected(MenuItem item) {

                    switch (item.getItemId()) {
                        case R.id.nav_home:
                            Intent intentTwo = new Intent(LibraryMain.this, HomeActivity.class);
                            startActivity(intentTwo);
                            overridePendingTransition(0,0);
                            break;
                        case R.id.nav_library:
                            // Does nothing as this is PlayListMain
                            break;
                        case R.id.nav_current_song:
                            Intent intent = new Intent(LibraryMain.this, CurrentlyPlayingActivity.class);
                            startActivity(intent);
                            overridePendingTransition(0,0);
                            break;
                    }
                    return true;
                }
    };

    // Top navigation bar listener
    private NavigationBarView.OnItemSelectedListener topNavListener =
            new NavigationBarView.OnItemSelectedListener() {
            @Override
            public boolean onNavigationItemSelected(MenuItem item) {

                switch (item.getItemId()) {
                    case R.id.top_nav_add:
                        addView();
                        // Bring up a menu which allows for creation of playlist
                        // Deleted placeholder case so this is why its a switch statement
                        break;
                }
                return true;
            }
    };

    // This view creates a pop up menu. The purpose of this pop-up menu is to allow users to create new playlists.
    private void addView() {
        View newView = getLayoutInflater().inflate(R.layout.popup_playlistnameprompt, null);
        // TODO: Fix this hard code at some point
        final PopupWindow newWindow = new PopupWindow(newView, 500, 500, true);
        newWindow.showAtLocation(newView.getRootView(), Gravity.CENTER, 0, 0);

        // All the buttons/edit text created
        Button addPlaylistBtn, exitBtn;
        EditText enterPlaylistName;
        enterPlaylistName = newView.findViewById(R.id.enterPlaylistName);
        addPlaylistBtn =  newView.findViewById(R.id.addButton);
        exitBtn = newView.findViewById(R.id.exitButton);

        addPlaylistBtn.setOnClickListener(new View.OnClickListener(){
            @Override
            public void onClick(View view){
                String playlistName = enterPlaylistName.getText().toString();
                ViewGroup parent = (ViewGroup) newView.getParent();
                if(playlistName.equals("")){
                    enterPlaylistName.setHint("Enter a different value");
                } else {
                    addToPlaylistList(playlistName);
                    // Exit popup after adding playlist
                    if (parent != null) {
                        parent.removeView(newView);
                    }
                }
            }

        });

        // Removes the pop up window when clicked
        exitBtn.setOnClickListener(new View.OnClickListener(){
            @Override
            public void onClick(View view) {
                ViewGroup parent = (ViewGroup) newView.getParent();
                if(parent != null){
                    parent.removeView(newView);
                }
            }
        });

    }

    // Creates playlist and adds it to current list of playlists for the user
    public void addToPlaylistList(String playlistName){

        // Check playlist list to see if playlist name exists. If it does, demand a different name
        if(currentPlaylists.isEmpty()){
            Playlist playlist = new Playlist(playlistName);

            // add this playlist to currentPlaylists
            Gson objGson = new Gson();
            currentPlaylists.add(playlist);
            String jsonString = objGson.toJson(currentPlaylists);
            updateCurrentPlayLists(jsonString);

        } else {
            boolean present = false;
            // Check through currentPlaylists to see if name already exists
            for(int i = 0; i < currentPlaylists.size(); i++) {
                if(currentPlaylists.get(i).getName().equals(playlistName)) {
                    Toast.makeText(getApplicationContext(), "This name is already taken", Toast.LENGTH_SHORT).show();
                    present = true;
                    break;
                }
            }
            // if playlistName isn't found as a title in currentPlaylists
            if(!present) {
                // If playlist name doesn't exist, create playlist
                Playlist playlist = new Playlist(playlistName);

                // TEST CODE TODO: REMOVE THIS ONCE SEARCH FUNCTION WORKS
                Song firstSong = new Song("Better Days");
                Song secondSong = new Song("Energy");
                Song thirdSong = new Song("Spirit Blossom");
                playlist.addSong(firstSong);
                playlist.addSong(secondSong);
                playlist.addSong(thirdSong);

                if(checkForDownloads("Better Days.mp3") == false) {
                    downloadSong(firstSong.getTitle());
                } //
                if(checkForDownloads("Energy.mp3") == false) {
                    downloadSong(secondSong.getTitle());
                } //
                if(checkForDownloads("Spirit Blossom.mp3") == false) {
                    downloadSong(thirdSong.getTitle());
                } // TODO: END REMOVE

                // Add playlist to currentPlaylists
                Gson objGson = new Gson();
                currentPlaylists.add(playlist);
                String jsonString = objGson.toJson(currentPlaylists);
                updateCurrentPlayLists(jsonString);
                // Test Code

            }
        }
    }

    /**
     * This method accepts a jsonString containing a playlist object, puts the playlist object
     * into currentPlaylists, and puts currentPlaylists
     * into SharedPreferences
     * @Param jsonString takes a jsonString containing a playlist object
     */
    public void updateCurrentPlayLists (String jsonString ) {
        SharedPreferences.Editor editor = preferences.edit();
        editor.putString("listListKey", jsonString);
        editor.apply();
    }

    // First, OUTSIDE of this method, check to see if the playlist even exists.
    // If it doesn't exist, pop up a toast saying the playlist doesn't exist Then do nothing
    // If it does exist, then run this method:
    // As a precursor, this method presumes that the search feature is working properly.
    // This either asks for the Song or the Song title/filename depending.
    // May need to append .mp3 to title/filename holding string at different points during this
    // The submethods work; however "addSongToPlaylist is NOT confirmed to work.
    public void addSongToPlaylist(String playlistName, Song song) {
    // First thing we want to do is see if the song is already downloaded. If the song is already downloaded, add the song to the playlist.
        if(checkForDownloads(song.getTitle())) {
            insertSong(playlistName, song);

        // If the song doesn't exist in the downloads,
        } else {
            // Download the song
            downloadSong(song.getTitle());
            // Check to see if song exists again. If it downloaded, insert to playlist.
            if(checkForDownloads(song.getTitle())) {
                insertSong(playlistName, song);
            }

        }
    }

    // ONLY GETS RUN INSIDE OF addSongToPlaylist
    // This method assumes that playlist has been confirmed to exist
    // THIS METHOD HAS NOT BEEN CONFIRMED FUNCTIONAL YET
    public void insertSong(String playlistName, Song song) {
        SharedPreferences preferences = getSharedPreferences("playlistList", LibraryMain.MODE_PRIVATE); // This line may need to change depending on where we add songs from

        // Check each playlist in currentPlaylists. If the playlist title matches, add song to that playlist
        for(Playlist i: LibraryMain.currentPlaylists) {
            if(i.getName().equals(playlistName)) {
                int position = LibraryMain.currentPlaylists.indexOf(i);
                LibraryMain.currentPlaylists.get(position).addSong(song);
                Gson objGson = new Gson();
                String jsonString = objGson.toJson(LibraryMain.currentPlaylists);
                SharedPreferences.Editor editor = preferences.edit();
                editor.putString("listListKey", jsonString);
                editor.apply();
                Toast.makeText(getApplicationContext(), "Song successfully added?", Toast.LENGTH_SHORT).show();
            }
        }
    }

    // Method confirmed functional. Move this to wherever we end up downloading songs from
    private void downloadSong (String songTitle) {
        storageReference= firebaseStorage.getInstance().getReference();
        ref = storageReference.child(songTitle + ".mp3"); // May need to add ".mp3" in here somehow, gotta see how this ends up working out

        ref.getDownloadUrl().addOnSuccessListener(new OnSuccessListener<Uri>() {
            @Override
            public void onSuccess(Uri uri) {
                String url = uri.toString();
                downloadFiles(songTitle, url);
            }
        }).addOnFailureListener(new OnFailureListener() {
            @Override
            public void onFailure(@NonNull Exception e) {

            }
        });

    }

    /**
     * THIS THING GETS MOVED TO WHEREVER WE'RE ADDING SONGS FROM
     * This method is confirmed functional
     */
    public void downloadFiles(String fileName, String url) {

        Uri uri = Uri.parse(url);
        DownloadManager.Request request = new DownloadManager.Request(uri);
        request.setNotificationVisibility(DownloadManager.Request.VISIBILITY_VISIBLE_NOTIFY_COMPLETED);
        request.setMimeType("audio/MP3");
        request.setDestinationInExternalPublicDir(DIRECTORY_MUSIC, fileName + ".mp3");
        DownloadManager downloadManager = (DownloadManager) getSystemService(Context.DOWNLOAD_SERVICE);
        downloadManager.enqueue(request);

    }

    /**
     * Checks if the fileName provided exists in DIRECTORY_MUSIC
     *  @param fileName - The name of the file, probably case sensitive
     *  @return - True/False depending if the file exists or not
     * Method is confirmed functional
     */
    public boolean checkForDownloads(String fileName) {
        return (new File(Environment.getExternalStoragePublicDirectory(DIRECTORY_MUSIC), fileName).exists());
    }

}

