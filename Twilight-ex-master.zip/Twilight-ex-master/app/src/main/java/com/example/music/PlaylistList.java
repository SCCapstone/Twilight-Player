package com.example.music;

import java.util.ArrayList;

public class PlaylistList {


    // Nick I am cribbing all your code from Playlist for this, thanks friend. If a playlist is a list of songs,
    // Then a PlaylistList is a list of playlists.
    // Now that I made this I'm not sure how useful it is. Might be useful for distinguishing playlists between users, maybe.
    // Maybe.
    private ArrayList<Playlist> playlistlist;
    private String name;

    public PlaylistList () {
        this.name = "temp";
        this.playlistlist = new ArrayList<Playlist>();
    }

    // Constructs a playlistList object with a blank list of playlists
    public PlaylistList(String name){
        this.name = name;
        this.playlistlist = new ArrayList<Playlist>();
    }

    // Constructs a playlistList object with the given name and list of playlists
    public PlaylistList(String name, ArrayList<Playlist> playlistlist) {
        this.name = name;
        this.playlistlist = playlistlist;
    }

    // Adds a playlist to the end of a playlistList
    public void addPlaylist(Playlist newPlaylist) {
        playlistlist.add(newPlaylist);
    }

    //Checks whether this playlistList contains a playlist
    public boolean containsPlaylist(Playlist playlist) {
        return playlistlist.contains(playlist);
    }

    // Adds a playlist at a specific index
    public void addPlaylistAt(Playlist newPlaylist, int location) {
        playlistlist.add(location, newPlaylist);
    }

    // Clears current playlistList
    public void clearPlaylistList() {
        playlistlist.clear();
    }

    // Removes a specific playlist from the playlistList
    public void removePlaylist(Playlist playlist) {
        if(containsPlaylist(playlist)){
            playlistlist.remove(playlist);
        }
    }

    // Returns the size of the playlistList
    public int getSize() {
        return playlistlist.size();
    }

    // Returns a playlist at a specific location
    public Playlist getPlaylistAt(int location) {
        if(location >= 0 && location <= playlistlist.size()) {
            return playlistlist.get(location);
        }else {
            return null;
        }
    }

    // Sets the name of the playlistList
    public void setName(String name) {
        this.name = name;
    }

    // Returns the name of the playlist
    public String getName() {
        return this.name;
    }

    // Sets the list of songs to a given argument
    public void setPlaylistList(ArrayList<Playlist> playlistlist) {
        this.playlistlist = playlistlist;
    }

    // Returns the list of playlists
    public ArrayList<Playlist> getPlaylistList() {
        return this.playlistlist;
    }

    // Checks if a given PlaylistList object is equal to this PlaylistList object
    public boolean equals(PlaylistList list) {
        if(this.name == list.getName() && this.playlistlist == list.getPlaylistList()) {
            return true;
        } else {
            return false;
        }
    }

}
