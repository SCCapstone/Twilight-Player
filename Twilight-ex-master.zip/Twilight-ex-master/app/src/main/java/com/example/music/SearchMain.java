package com.example.music;

import android.content.Intent;
import android.os.Bundle;
import android.view.MenuItem;
import androidx.annotation.Nullable;
import androidx.appcompat.app.AppCompatActivity;
import com.google.android.material.navigation.NavigationBarView;

import android.widget.ArrayAdapter;
import android.widget.ListView;

import java.util.ArrayList;

public class SearchMain extends AppCompatActivity {
    ListView listView;
    ArrayList<String> stringArrayList = new ArrayList<>();
    ArrayAdapter<String> adapter;

    @Override
    protected void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_search_main);

        // Creates bottom navigation bar and sets listener for it
        NavigationBarView bottomNav = findViewById(R.id.bottom_navigation_menu);
        bottomNav.setOnItemSelectedListener(navListener);
        bottomNav.setSelectedItemId(R.id.nav_search_bar);

        /*listView = findViewById(R.id.lv_listView);
        for(int i = 0; i <= 100; i++){
            stringArrayList.add("Item " + i);
        }

        adapter = new ArrayAdapter<>(SearchMain.this, android.R.layout.simple_list_item_1, stringArrayList);
        listView.setAdapter(adapter);
        listView.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> adapterView, View view, int position, long id) {
                Toast.makeText(getApplicationContext(),adapter.getItem(position),Toast.LENGTH_SHORT).show();
            }
        });*/
    }

    private NavigationBarView.OnItemSelectedListener navListener =
            new NavigationBarView.OnItemSelectedListener() {
                @Override
                public boolean onNavigationItemSelected(MenuItem item) {
                    switch (item.getItemId()) {
                        case R.id.nav_home:
                            Intent intentTwo = new Intent(SearchMain.this, HomeActivity.class);
                            startActivity(intentTwo);
                            overridePendingTransition(0,0);
                            break;
                        case R.id.nav_library:
                            Intent intent = new Intent(SearchMain.this, LibraryMain.class);
                            startActivity(intent);
                            overridePendingTransition(0,0);
                            break;
                        case R.id.nav_current_song:
                            Intent intentThree = new Intent(SearchMain.this, CurrentlyPlayingActivity.class);
                            startActivity(intentThree);
                            overridePendingTransition(0,0);
                            break;
                    }
                    return true;
                }
            };

}