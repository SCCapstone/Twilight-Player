package com.example.music;


import android.content.Context;
import android.net.Uri;
import android.os.Environment;
import android.provider.Settings;
import android.widget.Toast;

import com.google.android.exoplayer2.ExoPlayer;
import com.google.android.exoplayer2.MediaItem;
import com.google.android.exoplayer2.upstream.DataSource;

import java.io.File;
import java.util.ArrayList;

public class SongPlayer {

    public ExoPlayer player;
    private Playlist currplaylist;
    private ArrayList<Song> queue;
    private String repeat;
    private boolean isPaused;
    private boolean isPlayingQueue; //Used to determine where to get current song from
    private long songStartTime;

    /**
     * Constructs a SongPlayer object
     * @param context - The current activity's context
     */
    public SongPlayer(Context context) {
        this.player = new ExoPlayer.Builder(context).build();
        this.queue = new ArrayList<Song>();
        repeat = "";
        isPaused = false;
    }

    /**
     * Adds a song to the queue
     * @param song - The song to add
     */
    public void queueSong(Song song) {
        this.queue.add(song);
    }

    /**
     * Returns the current queue object
     * @return - Current queue
     */
    public ArrayList<Song> getQueue() {
        return this.queue;
    }

    /**
     * Inserts a song next within the queue
     * @param song - The song to be inserted
     */
    public void loadSong(Song song) {
        this.queue.add(player.getCurrentMediaItemIndex() + 1, song);
    }

    /**
     * Seeks to a specific spot within a song
     * @param time - The time to seek to
     */
    public void seekTo(long time) {
        if(time < player.getContentDuration()) {
            player.seekTo(time);
        }
    }

    /**
     * Plays the current queue, does nothing if the player is currently playing
     * In order to play a new queue the stopPlaying() method must be called first
     * Then load/clear the queue using queueSong() and clearQueue()
     * Finally call this method
     */
    public void playQueue() {
        if (!player.isPlaying()) {
            if (isPaused) {
                player.play();
                isPaused = false;
            } else {
                setupPlayerFromQueue();
                player.play();
                isPlayingQueue = true;
                songStartTime = System.currentTimeMillis();
                isPaused = false;
            }
        }
    }

    /**
     * Plays the given playlist, does nothing if the player is currently playing
     * In order to play a new playlist the stopPlaying() method must be called first
     * @param list - The playlist to be played
     */
    public void playFromPlaylist(Playlist list) {
        //If the player is not playing a song
        if (!player.isPlaying()) {
            if (isPaused) {
                player.play();
                isPaused = false;
            } else {
                setupPlayerFromPlaylist(list);
                player.play();
                this.currplaylist = list;
                isPlayingQueue = false;
                songStartTime = System.currentTimeMillis();
                isPaused = false;
            }
        }
    }

    /**
     * Stops the player, required to be called in order to play a new queue or playlist
     */
    public void stopPlaying() {
        isPaused = false;
        player.pause();
        player.stop();
    }

    /**
     * Seeks to the next song
     */
    public void nextSong() {
        player.seekToNext();
        songStartTime = System.currentTimeMillis();
    }

    /**
     * Seeks to the previous song
     */
    public void previousSong() {
        player.seekToPrevious();
        songStartTime = System.currentTimeMillis();
    }

    /**
     * Pauses the current song
     */
    public void pauseSong() {
        isPaused = true;
        player.pause();
    }

    /**
     * Does not do anything currently
     * @param text - Idk just followed the UML here
     */
    public void setRepeat(String text) {
        //TODO: Make this do something
        this.repeat = text;
    }

    /**
     * Returns the current song playing
     * @return - The currently playing song object
     */
    public Song getCurrentSong() {
        if(isPlayingQueue) {
            return this.queue.get(player.getCurrentMediaItemIndex());
        }else {
            return this.currplaylist.getSongAt(player.getCurrentMediaItemIndex());
        }
    }

    /**
     * Does not do anything currently
     * @param volume
     */
    public void setVolume(float volume) {
        //TODO: Add volume control somehow
    }

    /**
     * Gets the current song duration (I think?)
     * @return - The current song's Duration (Maybe?)
     */
    public long getSongDuration() {
        return player.getDuration();
    }

    /**
     * Returns elapsed time in milliseconds
     * WORKS CURRENTLY ONLY IF THE SONG IS NOT PAUSED
     * @return - Elapsed time for a song in milliseconds
     */
    public long getElapsedTime() {
        return System.currentTimeMillis() - songStartTime;
    }

    /**
     * Sets the queue object to an argument
     * @param queue - The new queue of Song objects
     */
    public void setQueue(ArrayList<Song> queue) {
        this.queue = queue;
    }

    /**
     * Returns whether the player is playing or not
     * @return - Is the player playing?
     */
    public boolean isPlaying() {
        return player.isPlaying();
    }

    /**
     * Clears the current queue
     */
    public void clearQueue() {
        this.queue.clear();
    }

    /**
     * Clears all media items in the player object, along with stopping the player
     */
    private void clearMediaQueue() {
        player.pause();
        player.stop();
        player.clearMediaItems();
    }

    /**
     * Sets up all the media items from the current queue object
     */
    private void setupPlayerFromQueue() {
        MediaItem item;
        clearMediaQueue();
//        for(Song song : queue) {
//            item = MediaItem.fromUri(song.getURL());
//            player.addMediaItem(item);
//        }

        for(Song song : queue) {
            //test
            File path = Environment.getExternalStoragePublicDirectory(Environment.DIRECTORY_MUSIC);
            File file = new File(path, song.getTitle() + ".mp3");
            Uri uri = Uri.fromFile(file);
            item = MediaItem.fromUri(uri);
            player.addMediaItem(item);
        }

        player.prepare();
    }

    /**
     * Sets up all the media items from a given playlist object
     * @param list - The playlist to be played
     */
    private void setupPlayerFromPlaylist(Playlist list) {
        MediaItem item;
        clearMediaQueue();
//        for(Song song : list.getSongs()) {
//            item = MediaItem.fromUri(song.getURL());
//            player.addMediaItem(item);
//        }

        for(Song song : list.getSongs()) {
            //test
            File path = Environment.getExternalStoragePublicDirectory(Environment.DIRECTORY_MUSIC);
            File file = new File(path, song.getTitle() + ".mp3");
            Uri uri = Uri.fromFile(file);
            item = MediaItem.fromUri(uri);
            player.addMediaItem(item);
        }

        player.prepare();
    }
}
